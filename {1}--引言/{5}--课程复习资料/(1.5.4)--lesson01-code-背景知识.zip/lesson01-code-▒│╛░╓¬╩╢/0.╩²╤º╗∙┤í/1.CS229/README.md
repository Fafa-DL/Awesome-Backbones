# CS 229 机器学习课程复习材料

文件夹的材料斯坦福大学CS 229机器学习课程的基础材料的翻译版本，[原始文件下载](http://cs229.stanford.edu/summer2019/cs229-linalg.pdf)

翻译：[黄海广](https://github.com/fengdu78)
备注：请关注[github](https://github.com/fengdu78/Data-Science-Notes/tree/master/0.math)的更新，近期将更新完。

markdown文件夹是文件的markdown代码，内容与pdf一致，是为了方便研究者写论文或者文章使用。

github内容是方便用户学习研究使用，请勿用于商业目的。

如果需要引用这个Repo:

格式： `fengdu78, Data-Science-Notes, (2019), GitHub repository, https://github.com/fengdu78/Data-Science-Notes`
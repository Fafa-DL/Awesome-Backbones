# Pandas练习题50题

>作者：王大毛，和鲸社区
>
>出处：https://www.kesci.com/home/project/5ddc974ef41512002cec1dca
>
>修改：黄海广

Pandas 是基于 NumPy 的一种数据处理工具，该工具为了解决数据分析任务而创建。Pandas 纳入了大量库和一些标准的数据模型，提供了高效地操作大型数据集所需的函数和方法。 这些练习着重DataFrame和Series对象的基本操作，包括数据的索引、分组、统计和清洗。